# SUPPLEMENTARY MATERIAL: Coding Manual for Cross-Linguistic Intrusions (CLIs)

## 1. Objective
The purpose of this manual is to provide a standardized framework for the identification, categorization, and analysis of cross-linguistic intrusions (CLIs) in the target language (L5 Spanish) production of a higher-order multilingual participant.

## 2. Operational Definitions of Intrusions
An intrusion is defined as the spontaneous production of a linguistic element from a non-target language (L1-L4) within a target-language utterance.

### 2.1. Lexical Intrusions
- Definition: The substitution of a target-language word with a word from another language in the participant's repertoire.
- Example: Producing the Russian word "Dva" instead of the Spanish "Dos".
- Coding Criterion: Any instance where a word from L1-L4 is used to fill a semantic slot intended for L5.

### 2.2. Morphosyntactic Intrusions
- Definition: The application of the grammatical, syntactic, or morphological rules of a source language to the target language.
- Example: Applying Russian case markings or word-order patterns to a Spanish sentence.
- Coding Criterion: Instances where the error is not a single word substitution but a structural deviation that mirrors the grammar of a source language.

### 2.3. Phonological Intrusions
- Definition: The influence of a source language's phonology on the pronunciation of a target language word, resulting in an identifiable foreign phonetic pattern.
- Coding Criterion: Occurrences where the pronunciation deviates from L5 norms in a way that is characteristic of a specific source language (e.g., L4 phonemes).

---

## 3. Inhibitory Resolution and Repair Coding
Self-repairs were analyzed based on the temporal and behavioral response following the intrusion.

### 3.1. Prompt Self-Repair (Rapid Monitoring)
- Criteria: The participant detects the intrusion and corrects it almost immediately. 
- Observables: Short pause duration (<= 500ms); no disruption in the overall prosodic flow; immediate lexical substitution.
- Interpretation: High inhibitory stability.

### 3.2. Delayed Self-Repair
- Criteria: The participant detects the intrusion after a significant temporal gap or after completing the phrase.
- Observables: Pronounced pauses (> 500ms); fragmented speech; correction occurs after an external prompt or a long internal reflection.
- Interpretation: Fragile inhibitory control.

### 3.3. Unrepaired Intrusion (Inhibitory Failure)
- Criteria: The intrusion remains in the utterance and is not corrected by the participant.
- Interpretation: Total failure of the inhibitory mechanism for that specific item.

---

## 4. Analysis Procedure
1. Transcription: All audio recordings were transcribed verbatim.
2. Identification: Every instance of non-L5 production was flagged.
3. Categorization: Each flagged item was categorized as Lexical, Morphosyntactic, or Phonological.
4. Behavioral Analysis: The time-interval between the intrusion and the repair was measured to determine the "Repair Tendency" (Prompt vs. Delayed).
